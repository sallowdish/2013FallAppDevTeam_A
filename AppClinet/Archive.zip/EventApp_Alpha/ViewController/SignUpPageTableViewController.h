//
//  SignUpPageTableViewController.h
//  EventApp_Alpha
//
//  Created by Rui Zheng on 2014-04-27.
//  Copyright (c) 2014 2013_Fall_Dev_Team_A. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GKImagePicker.h"

@interface SignUpPageTableViewController : UITableViewController<GKImagePickerDelegate>

@end
