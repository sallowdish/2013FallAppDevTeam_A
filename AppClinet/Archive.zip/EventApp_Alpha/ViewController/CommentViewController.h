//
//  CommentViewController.h
//  EventApp_Alpha
//
//  Created by Rui Zheng on 2/11/2014.
//  Copyright (c) 2014 2013_Fall_Dev_Team_A. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommentViewController : UITableViewController

@end
